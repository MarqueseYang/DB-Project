from pymongo import MongoClient
import pandas as pd
from sentence_transformers import SentenceTransformer
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
MONGO_URI= "mongodb+srv://yangqikai04:DBProject@database.rpt54sl.mongodb.net/"

client = MongoClient(MONGO_URI)
db = client["eda_project"]

# Use Case 1 - Chronic Disease Risk Prediction - Classification
df_claim = pd.DataFrame(list(db.FactClaimChronic.find()))
df_customer = pd.DataFrame(list(db.DimCustomer.find()))
df_notes = pd.DataFrame(list(db.ClinicalNote.find()))

df = df_customer.merge(df_claim, on="CustomerID", how="left")
df = df.merge(df_notes[["CustomerID", "NoteText"]], on="CustomerID", how="left")
df["NoteText"] = df["NoteText"].fillna("")

model_bert = SentenceTransformer("all-MiniLM-L6-v2")
df["embedding"] = df["NoteText"].apply(lambda x: model_bert.encode(x))
emb = np.vstack(df["embedding"].values)

df["ChronicClaimCount"] = df.groupby("CustomerID")["ClaimID"].transform("count")
X_struct = df[["Age", "Gender", "ChronicClaimCount"]].fillna(0).to_numpy()

X = np.hstack([X_struct, emb])

df["label"] = df["ChronicClaimCount"].apply(lambda x: 1 if x > 0 else 0)
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

clf = XGBClassifier(n_estimators=200, max_depth=6)
clf.fit(X_train, y_train)

pred = clf.predict(X_test)
print(classification_report(y_test, pred))

# Use case 2 - Claim Severity Prediction - Regression
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, r2_score

df = df.merge(df_notes[["CustomerID", "NoteText"]], on="CustomerID", how="left")
df["NoteText"] = df["NoteText"].fillna("")
df["embedding"] = df["NoteText"].apply(lambda x: model_bert.encode(x))
emb = np.vstack(df["embedding"].values)

df["ClaimAmount"] = df["ClaimAmount"].fillna(0)
X = np.hstack([df[["Age", "StressLevelIndex"]].fillna(0).to_numpy(), emb])
y = df["ClaimAmount"].to_numpy()

X_train, X_test, y_train, y_test = train_test_split(X, y)

reg = XGBRegressor(n_estimators=300, max_depth=7)
reg.fit(X_train, y_train)

pred = reg.predict(X_test)
print("RMSE:", mean_squared_error(y_test, pred, squared=False))
print("R2:", r2_score(y_test, pred))

# Use case 3 - Future Healthcare Cost Forecasting - Time-Series Regression
df_cost = pd.DataFrame(list(db.FactCostPerCapita.find()))

cost_summary = df_cost.groupby("CustomerID")["CostAmount"].agg(["mean", "sum", "std"])
cost_summary.columns = ["MeanCost", "TotalCost", "CostStd"]

df = df_customer.merge(cost_summary, on="CustomerID", how="left").fillna(0)

df["FutureCost"] = df["MeanCost"] * 12

X = df[["Age", "Gender", "MeanCost", "CostStd"]].to_numpy()
y = df["FutureCost"].to_numpy()

X_train, X_test, y_train, y_test = train_test_split(X, y)

model_ts = XGBRegressor(n_estimators=300)
model_ts.fit(X_train, y_train)

pred = model_ts.predict(X_test)
print("RMSE:", mean_squared_error(y_test, pred, squared=False))

# Use case 4 - Fraud Detection - Anomaly Detection
from sklearn.ensemble import IsolationForest

df_claim["AmountZScore"] = (df_claim["ClaimAmount"] - df_claim["ClaimAmount"].mean()) / df_claim["ClaimAmount"].std()
df_claim["TimeSinceLastClaim"] = df_claim.groupby("CustomerID")["ClaimDate"].diff().dt.days.fillna(999)

X = df_claim[["AmountZScore", "TimeSinceLastClaim"]].fillna(0)

model_fraud = IsolationForest(contamination=0.05)
df_claim["anomaly_score"] = model_fraud.fit_predict(X)

fraud_cases = df_claim[df_claim["anomaly_score"] == -1]
print("Possible fraud cases:")
print(fraud_cases.head())

# Use case 5 - Customer Risk Segmentation - K-Means Clustering
from sklearn.cluster import KMeans

df["RiskScore"] = clf.predict(X)  # from Use Case 1
df["SeverityPred"] = reg.predict(X)  # from Use Case 2

cluster_input = df[["RiskScore", "SeverityPred", "AvgMonthlyCost"]].fillna(0)

kmeans = KMeans(n_clusters=4, random_state=42)
df["Cluster"] = kmeans.fit_predict(cluster_input)

print(df[["CustomerID", "Cluster"]].head())

# Use case 6 — Product Recommendation & Dynamic Pricing
product_clf = XGBClassifier()
product_clf.fit(X_train, df_customer.loc[X_train.index, "PreferredProduct"])

product_preds = product_clf.predict(X_test)

premium_reg = XGBRegressor()
premium_reg.fit(X_train, df_customer.loc[X_train.index, "PremiumPaid"])

premium_preds = premium_reg.predict(X_test)
